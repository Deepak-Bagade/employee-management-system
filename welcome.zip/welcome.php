<?php  
session_start();  
  if(!$_SESSION['email'])  
{  
header("Location: login.php");
}  
?>  
 
<html>  
<style>
  body{background-image: conic-gradient(lightpink,lightpink);}
</style>
<head>  
<title> Welcome!</title>  
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap.min.css">

<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap-theme.css">
<script src="bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>  
  <center>
<body> 
<nav class="navbar bg-info">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Employee Management</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
     <li><a href="http://localhost/my%20php/insert1.php">Insert</a></li>
      <li><a href="http://localhost/my%20php/searchemploye.php">Search</a></li>
      <li><a href="http://localhost/my%20php/update1.php">Update</a></li>
      <li><a href="http://localhost/my%20php/delete1.php">Delete</a></li>
</ul>

<ul class="nav navbar-nav navbar-right">
      <li><a href="http://localhost/my%20php/reguser.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="http://localhost/my%20php/login.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
    </ul>


<form class="navbar-form navbar-left" action="/action_page.php">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Search">
      </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>

 </div>
</nav>

<h2 class="bg-primary"> Welcome :
<?php echo $_SESSION['email']; ?>   </h2>

<hr>

<div class="container">
<div class="jumbotron">

<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="e.webp" alt="Employee Management System">
    </div>

    <div class="item">
      <img src="em.jpg" alt="Employee">
    </div>

    <div class="item">
      <img src="emp.jpg" alt="Employee">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<code> Salary Information </code>
<code> Department Details </code>
<code> Inventory information </code>
<code> Employee Training </code>
</div>
</div>

<table class="table table-striped table-hover ">
<tr class="primary">

      <td align="center"><div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">Insert Records</h3>
  </div>
  <div class="panel-body">
<img src="el1.jpeg" width=200 height=200><br>
<a href="http://localhost/my%20php/insert1.php">   <button type="button" class="btn btn-primary">insert</button> </a>
  </div>
</div></td>
      <td align="center"><div class="panel panel-warning">
  <div class="panel-heading">
    <h3 class="panel-title">Search Records</h3>
  </div>
  <div class="panel-body">
<img src="el2.jpg" width=200 height=200> <br>
<a href="http://localhost/my%20php/searchemploye.php">
   <button type="button" class="btn btn-warning">search</button></a>

  </div>
</div></td>

  <td align="center"><div class="panel panel-success">
  <div class="panel-heading">
    <h3 class="panel-title">Update</h3>
  </div>
 
 <div class="panel-body">
<img src="el3.png" width=200 height=200><br>
<a href="http://localhost/my%20php/update1.php">
   <button type="button" class="btn btn-success">update</button></a>
  </div>

</div></td>

  <td align="center"><div class="panel panel-danger">
  <div class="panel-heading">
    <h3 class="panel-title">Delete</h3>
  </div>
 
 <div class="panel-body">
<img src="el4.png" width=200 height=200><br>
<a href="http://localhost/my%20php/delete1.php">
   <button type="button" class="btn btn-danger">delete</button></a>
  </div>

</div></td>

    </tr>
</table>

<div class="bg-info">
<a href="http://localhost/my%20php/contact.php">Contact us</a> |
<a href="http://localhost/my%20php/location.php"> Address location </a> | 
<a href="#"> Service </a> |
<a href="#"> Products </a> |
<a href="http://localhost/myphp/update.php"> Update </a> |
<a href="http://localhost/myphp/student.php"> Search </a>
<br>


</div>

</body>  
</html>